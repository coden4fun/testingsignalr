﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SignalRTest.Models
{
    public class WCFModel
    {
        public string testworked = string.Empty;
        public List<viewEstimateRpt> viewEstimateRpts { get; set; }
        public List<viewTimeByEmployeeAndClient> viewTimeByEmployeeAndClient { get; set; }
    }

    public partial class viewEstimateRpt
    {
        public System.Guid EstimateId { get; set; }
        public string EstimateName { get; set; }
        public string EstimateType { get; set; }
        public string RevisionNumber { get; set; }
        public string IsApproved { get; set; }
        public Nullable<System.DateTime> ApprovalDate { get; set; }
        public Nullable<System.Guid> DisplayOptionId1 { get; set; }
        public Nullable<System.Guid> DisplayOptionId2 { get; set; }
        public Nullable<System.Guid> ApprovedEstimateOptionId { get; set; }
        public Nullable<System.Guid> ApproverUserId { get; set; }
        public string ClientName { get; set; }
        public string ProductLineName { get; set; }
        public string CampaignName { get; set; }
        public string JobName { get; set; }
        public System.Guid EstimateOptionId { get; set; }
        public string EstimateOptionName { get; set; }
        public decimal Quantity { get; set; }
        public string Username { get; set; }
        public string ApproverName { get; set; }
        public string JobFullName { get; set; }
        public string LinkField { get; set; }
    }

    public partial class viewTimeByEmployeeAndClient
    {
        public string EmployeeName { get; set; }
        public Nullable<decimal> TotalHours { get; set; }
        public string ClientName { get; set; }
        public string ProductLineName { get; set; }
        public string JobName { get; set; }
        public string TaskName { get; set; }
        public string CampaignName { get; set; }
    }
}